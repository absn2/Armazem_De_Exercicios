Questões Feitas pelo Grupo 4:

Antonio Netto (absn2)														
Francisco Marcos (fmln)										
André Ferreira Santos Sousa (afss2)									
Pedro Ribeiro (phrp)									
José Bezerra (jbmn)